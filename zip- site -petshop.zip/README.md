# Pet-Shop-Website
Shared project with Kristian Kirilov - making a Pet shop website


28.01.23г. 

sticky за подзаглавието

Работа върху снимките

промяна на Ul li-тата в подзаглавието.

търсене на скрипт за иконите и профили
....

